create procedure dataTableDB(IN tipo varchar(13), IN sec1 int, IN sec2 int, IN stringData varchar(9))
  BEGIN
    CASE tipo

      WHEN 'Até 2h' THEN

      SELECT inc.inc_codigo_incidente, inc.inc_criado, inc.inc_resolvido, SEC_TO_TIME(TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido)) as duracao, i.coi_descricao, bggd.grs_descricao, bee.emp_descricao, prioridade.pri_descricao,sumario.sum_descricao FROM bip_inc_incidente inc INNER JOIN bip_coi_codigo_ic i on inc.inc_coi_codigo_ic_id = i.coi_codigo_ic_id INNER JOIN bip_grs_grupo_designado bggd on inc.inc_grs_grupo_designado_id = bggd.grs_grupo_designado_id INNER JOIN bip_emp_empresa bee on bggd.grs_emp_empresa_id = bee.emp_empresa_id INNER JOIN bip_pri_prioridade prioridade on inc.inc_pri_prioridade_id = prioridade.pri_prioridade_id INNER JOIN bip_sum_sumario sumario on inc.inc_sum_sumario_id = sumario.sum_sumario_id WHERE inc_resolvido LIKE stringData AND TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido) <= sec1;

      WHEN 'Até 4h' THEN

      SELECT inc.inc_codigo_incidente, inc.inc_criado, inc.inc_resolvido, SEC_TO_TIME(TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido)) as duracao, i.coi_descricao, bggd.grs_descricao, bee.emp_descricao, prioridade.pri_descricao,sumario.sum_descricao FROM bip_inc_incidente inc INNER JOIN bip_coi_codigo_ic i on inc.inc_coi_codigo_ic_id = i.coi_codigo_ic_id INNER JOIN bip_grs_grupo_designado bggd on inc.inc_grs_grupo_designado_id = bggd.grs_grupo_designado_id INNER JOIN bip_emp_empresa bee on bggd.grs_emp_empresa_id = bee.emp_empresa_id INNER JOIN bip_pri_prioridade prioridade on inc.inc_pri_prioridade_id = prioridade.pri_prioridade_id INNER JOIN bip_sum_sumario sumario on inc.inc_sum_sumario_id = sumario.sum_sumario_id WHERE inc_resolvido LIKE stringData AND TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido) <= sec1 AND TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido) > sec2;

      WHEN 'Até 6h' THEN

      SELECT inc.inc_codigo_incidente, inc.inc_criado, inc.inc_resolvido, SEC_TO_TIME(TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido)) as duracao, i.coi_descricao, bggd.grs_descricao, bee.emp_descricao, prioridade.pri_descricao,sumario.sum_descricao FROM bip_inc_incidente inc INNER JOIN bip_coi_codigo_ic i on inc.inc_coi_codigo_ic_id = i.coi_codigo_ic_id INNER JOIN bip_grs_grupo_designado bggd on inc.inc_grs_grupo_designado_id = bggd.grs_grupo_designado_id INNER JOIN bip_emp_empresa bee on bggd.grs_emp_empresa_id = bee.emp_empresa_id INNER JOIN bip_pri_prioridade prioridade on inc.inc_pri_prioridade_id = prioridade.pri_prioridade_id INNER JOIN bip_sum_sumario sumario on inc.inc_sum_sumario_id = sumario.sum_sumario_id WHERE inc_resolvido LIKE stringData AND TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido) <= sec1 AND TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido) > sec2;

      WHEN 'Até 8h' THEN

      SELECT inc.inc_codigo_incidente, inc.inc_criado, inc.inc_resolvido, SEC_TO_TIME(TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido)) as duracao, i.coi_descricao, bggd.grs_descricao, bee.emp_descricao, prioridade.pri_descricao,sumario.sum_descricao FROM bip_inc_incidente inc INNER JOIN bip_coi_codigo_ic i on inc.inc_coi_codigo_ic_id = i.coi_codigo_ic_id INNER JOIN bip_grs_grupo_designado bggd on inc.inc_grs_grupo_designado_id = bggd.grs_grupo_designado_id INNER JOIN bip_emp_empresa bee on bggd.grs_emp_empresa_id = bee.emp_empresa_id INNER JOIN bip_pri_prioridade prioridade on inc.inc_pri_prioridade_id = prioridade.pri_prioridade_id INNER JOIN bip_sum_sumario sumario on inc.inc_sum_sumario_id = sumario.sum_sumario_id WHERE inc_resolvido LIKE stringData AND TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido) <= sec1 AND TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido) > sec2;

      WHEN 'Superior à 8h' THEN

      SELECT inc.inc_codigo_incidente, inc.inc_criado, inc.inc_resolvido, SEC_TO_TIME(TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido)) as duracao, i.coi_descricao, bggd.grs_descricao, bee.emp_descricao, prioridade.pri_descricao,sumario.sum_descricao FROM bip_inc_incidente inc INNER JOIN bip_coi_codigo_ic i on inc.inc_coi_codigo_ic_id = i.coi_codigo_ic_id INNER JOIN bip_grs_grupo_designado bggd on inc.inc_grs_grupo_designado_id = bggd.grs_grupo_designado_id INNER JOIN bip_emp_empresa bee on bggd.grs_emp_empresa_id = bee.emp_empresa_id INNER JOIN bip_pri_prioridade prioridade on inc.inc_pri_prioridade_id = prioridade.pri_prioridade_id INNER JOIN bip_sum_sumario sumario on inc.inc_sum_sumario_id = sumario.sum_sumario_id WHERE inc_resolvido LIKE stringData AND TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido) > sec1;

      WHEN 'TOTAL' THEN

      SELECT inc.inc_codigo_incidente, inc.inc_criado, inc.inc_resolvido, SEC_TO_TIME(TIMESTAMPDIFF(SECOND, inc_criado,inc_resolvido)) as duracao, i.coi_descricao, bggd.grs_descricao, bee.emp_descricao, prioridade.pri_descricao,sumario.sum_descricao FROM bip_inc_incidente inc INNER JOIN bip_coi_codigo_ic i on inc.inc_coi_codigo_ic_id = i.coi_codigo_ic_id INNER JOIN bip_grs_grupo_designado bggd on inc.inc_grs_grupo_designado_id = bggd.grs_grupo_designado_id INNER JOIN bip_emp_empresa bee on bggd.grs_emp_empresa_id = bee.emp_empresa_id INNER JOIN bip_pri_prioridade prioridade on inc.inc_pri_prioridade_id = prioridade.pri_prioridade_id INNER JOIN bip_sum_sumario sumario on inc.inc_sum_sumario_id = sumario.sum_sumario_id WHERE inc_resolvido LIKE stringData;

      END CASE;
  END;

